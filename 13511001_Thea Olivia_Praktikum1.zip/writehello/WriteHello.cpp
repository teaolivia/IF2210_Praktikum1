// File : WriteHello.cpp
/* NIM/Nama : 13511001/Thea Olivia
	Praktikkum 1 OOP */

#include <iostream>
#include "Proses.h"
using namespace std;

int main(){
	
	Proses P1, P2, P3;
	return 0;
}