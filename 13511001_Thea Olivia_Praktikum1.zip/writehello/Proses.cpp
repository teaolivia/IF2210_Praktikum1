// File : Proses.cpp
/* NIM/Nama : 13511001/Thea Olivia
	Praktikkum 1 OOP */
	
#include <iostream>
#include "Proses.h"
using namespace std;

Proses::Proses() { cout << "WriteHello" << endl; }

