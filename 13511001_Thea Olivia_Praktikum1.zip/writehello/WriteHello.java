// File : WriteHello.java
/* NIM/Nama : 13511001/Thea Olivia
	Praktikkum 1 OOP */
	
public class WriteHello(){

	public static void main (String[] args){
	// main
	Proses object = new Proses(P1, P2, P3);
}
}