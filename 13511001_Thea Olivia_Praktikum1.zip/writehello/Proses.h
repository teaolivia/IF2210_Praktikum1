// File : Proses.h
/* NIM/Nama : 13511001/Thea Olivia
	Praktikkum 1 OOP */
	
#ifndef _Proses_H
#define _Proses_H

class Proses {
	public:

	Proses();	//ctor
};

#endif