#include "point.h"

// Implementasi kelas point

// end
